# Corporate & B2B — Employee Portal (Customer-Side)

If user belongs to a company, show entitlements and usage.

---

## 1) Pages
- `/account/company`: company name, plan, seat/credit usage, eligible locations/classes.
- Billing handled by company; show policy (caps, blackout times).

## 2) Acceptance Criteria
- Prices and eligibility reflect company rate card; bookings deduct from company wallet or cap.
