# Marketing — Full Requirements & Spec (Funnels + Newsletters + Journeys)

A **full-funnel growth system** modeled after best-in-class “click funnels” platforms + CRM marketing suites. Includes **funnels & landing pages**, **newsletter engine with templates**, **journeys/automations**, **segmentation/CDP**, **offers (coupons/gift cards)**, **referrals**, **widgets**, **deliverability**, **analytics/attribution**, and **privacy**—deeply integrated with **Customers, Registrations, Products, Finance, Campaigns (Retreats/Programs/Guides), Online Studio**, and **Settings**.

> Swiss/EU ready (GDPR/nLPD), multilingual (FR/DE/IT/EN), CHF/VAT-aware, TWINT/SEPA-friendly; web + iOS/Android.

---

## 0) TL;DR — What this adds beyond the previous spec
- **Funnels** (multi-step flows): Opt-in → Sales → Checkout (order bump) → 1-click Upsell/Downsell → Thank-you.
- **Newsletter** suite: Template library, drag-drop editor, content blocks, AI copy, A/B, send-time optimization, deliverability tooling.
- **Unified CDP/Segmentation**: real-time behavioral + profile segments with dynamic membership.
- **Journey Builder**: visual, event-driven automations; quiet hours, frequency caps, goal exits.
- **Deep integration** with **Products/Registrations/Finance** for **revenue attribution**, coupons, payment plans, and “book/Buy” CTAs.
- **Consent & Preference Center**, **Bounce/Suppression** hygiene, **DKIM/SPF/DMARC** guidance.
- **Attribution** across campaigns, journeys, funnels, and on-site widgets, with revenue + cohort views.

---

## 1) Personas & Roles
- **Studio Owner/Marketer**: builds funnels, newsletters, automations; monitors ROI.
- **Instructor/Creator**: publishes programs/guides, emails their audience (within permissions).
- **Front Desk**: sends transactional and quick segments (e.g., “tonight’s class moved”).
- **Student/Lead**: receives messages, lands on pages, opts in/out, books, buys.

Permissions map to existing role system; marketing privilege scopes: `read`, `send`, `publish`, `admin`.

---

## 2) Information Architecture
1. **Funnels & Landing Pages**
2. **Campaigns** (newsletters/blasts)
3. **Journeys** (automations)
4. **Segments** (CDP audience builder)
5. **Templates & Assets** (email/page blocks, themes)
6. **Offers** (coupons, gift cards) & **Referrals**
7. **Widgets & Embeds** (schedule, product, lead capture)
8. **Deliverability & Compliance** (domains, consent, suppression)
9. **Attribution & Analytics** (reports, dashboards)
10. **Settings** (brand tokens, defaults, quiet hours, link shortener, UTM builder)

---

## 3) Architecture & Data Flow (high level)
- **Events in** from app/web (page views, form submits, add-to-cart, bookings, purchases, video plays).
- **CDP layer** normalizes → **Segments** update dynamically.
- **Journeys** subscribe to triggers & segment entry/exit; **Campaigns** query segments at send.
- **Funnels/pages** emit **attribution_events** with UTM/referral metadata.
- **Finance/Orders** send revenue events back → **Attribution** calculates ROI per touch.
- **Messages** (email/SMS/push/WhatsApp) managed via provider adapters with delivery/bounce webhooks.
- **Privacy** ensures channel opt-in, double opt-in, preference center compliance.

---

## 4) Data Model (relational sketch)

### Core
- `segments` (id, org_id, name, **definition_jsonb**, is_dynamic, refreshed_at, sample_count)
- `audiences` (optional static audience snapshots for compliance or A/B splits)
- `campaigns` (id, org_id, type **blast/journey**, **channel email/sms/push/whatsapp**, status draft/scheduled/sending/paused/completed, audience_ref, schedule_at, **ab_test_jsonb**, **goal_event**)
- `messages` (id, campaign_id, customer_id/lead_id, channel, provider, status queued/sent/bounced/complained/dropped, **opened_at, clicked_at**, **unsubscribed_at**, error_jsonb)
- `journeys` (id, org_id, name, **graph_jsonb** nodes/edges; status on/off; **entry_conditions**; **exits/goals**)
- `journey_enrollments` (journey_id, subject_id (customer/lead), state active/completed/exited, last_step, started_at, completed_at)
- `templates` (id, org_id, **kind email/page/sms**, blocks_jsonb, styles_jsonb, locale, versioning)
- `assets` (images/files with metadata; public/private; variants)

### Funnels & Pages
- `landing_pages` (id, org_id, slug, **content_jsonb**, seo_jsonb, locale, status draft/published, **funnel_id?, step_kind?**)
- `funnels` (id, org_id, name, **steps_jsonb** ordered; theme; **one_click_upsell_enabled**)
- `funnel_steps` (funnel_id, idx, **type** optin/sales/checkout/upsell/downswell/thankyou, **linkage** to product(s)/coupon(s), **conditions**)
- `forms` (id, org_id, **schema_jsonb**, validations, **double_opt_in** bool, captcha, privacy_check_required)
- `leads` (id, org_id, email, phone, name, locale, source, **consents_jsonb**, **attributes_jsonb**, status new/engaged/converted)
- `form_submissions` (form_id, lead_id?, payload_jsonb, **attribution_ref**)

### Attribution & Offers
- `attribution_events` (subject_id (lead/customer), session_id, source/medium/campaign/content/term, **page_url**, **funnel_step**, **first_touch_at, last_touch_at**, **order_id?**)
- `referrals` / `referral_conversions` (as defined in Loyalty spec)
- `coupons` / `gift_cards` (Products spec; reference here for distribution)

### Compliance & Deliverability
- `consents` (subject_id, channel email/sms/whatsapp/push, **status opt_in/opt_out**, **proof metadata**: ip, ua, version, locale, timestamp)
- `suppression_lists` (org_id, email/phone hash, reason bounce/complaint/manual)
- `sender_identities` (org_id, domain, dkim_selector, spf_verified, dmarc_policy, **warmup_status**)
- `link_shortener_clicks` (short_id, url, **channel**, **campaign_id**, **visitor_fingerprint**)

> All tables `org_id`-scoped; strict RLS; PII encrypted at rest where needed.

---

## 5) Segmentation (CDP)
- **Definition builder** with:
  - **Profile filters**: language, city, tags, lifetime spend, member/pass status, last class attended, interests, injury flags (if allowed), corporate company, age range.
  - **Behavioral filters**: visited page X, viewed video tag Y, added to cart but not purchased in 24h, viewed schedule but didn’t book, attendance frequency change.
  - **Event sequences**: OR/AND, “did A then NOT B within 7d”.
  - **Time windows**: rolling (e.g., last 30d) and fixed.
  - **Consent & channel availability** enforcement.
- **Dynamic membership** (continuous refresh; near-real-time for critical segments).
- **Lookalike** seed export to Ads platforms (hashed email/phone) with consent.

**APIs/RPCs**
- `evaluate_segment(segment_id)` → count & sample.
- `snapshot_segment(segment_id)` → `audiences` row for compliance or A/B.

---

## 6) Campaigns (Newsletters / Blasts)
- **Editor**: drag-drop blocks (hero, text, image, schedule grid, product list, testimonial, map, CTA, countdown), **AI copy assist**, image cropper, link checker.
- **A/B tests**: subject, preheader, content block variants, call-to-action; winner by **open/click/booking revenue** after N recipients or T minutes.
- **Send-time optimization**: per-recipient historical open/engagement window & timezone.
- **Send controls**: batch size, rate limit, retry on transient failure, exclude suppression lists, **seed/test send**.
- **Link tracking**: automatic UTM builder + **short links** (own domain).
- **Goals**: e.g., “class booked”, “order paid ≥ CHF 50”. Campaign auto-marks goal conversions via attribution joins.
- **Post-send management**: resends to non-openers (optional); follow-up/upsell variants.

**APIs/RPCs**
- `create_campaign(payload)`; `schedule_campaign(campaign_id, at)`; `pause_campaign`; `resume_campaign`.
- `ab_select_winner(campaign_id)` → switches to winning variant.
- Webhooks: `campaign.sent`, `message.bounced`, `message.complained`, `campaign.goal_reached`.

---

## 7) Journeys (Automations)
- **Visual builder** with nodes:
  - **Triggers**: signup, first booking, plan started/paused/failed, viewed class page, abandoned checkout, waitlist promoted, birthday, post-class, NPS detractor, churn-risk score change, referral joined.
  - **Conditions**: segment membership, attribute check, membership status, spend thresholds.
  - **Actions**: send email/SMS/push/WhatsApp, **add/remove tag**, **assign coupon** (unique codes), **grant pass credit**, **adjust wallet**, **create task**, **webhook**.
  - **Delays/Windows**: wait X hours, wait until day/time (respect **quiet hours & locale**).
  - **Branches**: if opened/clicked/booked; path A/B.
  - **Goals**: exit when booked/purchased; **re-entry** guardrails.
- **Frequency caps** (per channel & global), **priority** between journeys, **holdouts/control groups** for incremental lift.
- **Versioning**: immutable runs on publish; edits create v2 with safe migration of enrollees.

**APIs/RPCs**
- `start_journey(journey_id)` / `stop_journey`.
- `enroll(subject, journey_id)` / `unenroll`.
- `emit_event(subject, event_type, props)` (internal bus).

---

## 8) Funnels & Landing Pages (Click-Funnels style)
- **Funnel** = ordered **steps** with rules:
  1) **Opt-in** (lead form with **double opt-in** option).
  2) **Sales page** (offer; can show timer, testimonials, schedule grid).
  3) **Checkout** (integrates Products/Finance; supports **order bumps**).
  4) **Upsell** (**one-click** if payment token available) / **Downsell** fallback.
  5) **Thank-you** (next steps, referral CTA, add to calendar).
- **Themes**: brand tokens from Settings; custom CSS; block library; reusable sections.
- **Forms**: drag-drop fields, validation, captcha; map to lead fields or **custom attributes**; **consent checkboxes** (marketing, terms, waiver).
- **SEO**: slug, meta, OG/Twitter images, **hreflang**, **structured data** for Event/Offer.
- **A/B page tests** (layout, headline, CTA, price presentation).
- **Integrations**: deep link to mobile app; **webhook** on form submit; **pixel** injection (GA4/Meta) via privacy wrapper.

**Checkout specifics**
- **Products**: drop-ins/passes/memberships/workshops/retreat tiers; **coupon input**; **payment plans**; **gift cards**.
- **Order bump**: add-on with single toggle; **Upsell/Downsell**: instant post-purchase (no card entry if tokenized).
- **Compliance**: VAT display incl/excl, total due today, cancellation/refund policy snapshot.

---

## 9) Offers, Coupons, Gift Cards (Distribution layer)
- **Unique coupon code** generation per recipient; **bulk** generation for funnels/journeys.
- **Eligibility**: product/category restrictions, min spend, new customers only, location/time windows.
- **Gift cards**: campaign distribution, recipient email scheduling, reminder to use.
- **Wallet credit** rewards via Journeys (post-class review incentive, referral bonuses).

---

## 10) Referrals (Growth loops)
- **Share link** + QR; **traffic attribution** carries through funnel → checkout.
- Qualification rules: minimum order value, “new to studio”, cooldown; **fraud guard** (device/IP, self-referral block, velocity).
- **Reward**: wallet credit/free class/membership discount/gift card; **tiered rewards** (5 invites = 1 month free).

---

## 11) Widgets & Embeds
- **Schedule Widget** (with filters: location, instructor, tags), **Product Cards**, **Lead Capture** mini-form.
- Copy-paste JS snippet; **theme tokens** for brand styles.
- Events from widget → **attribution_events**.

---

## 12) Deliverability, Hygiene & Compliance
- **Sender setup**: DKIM, SPF, DMARC; domain warmup (gradual ramp), dedicated IP (Pro).
- **List hygiene**: bounce/complaint handling into **suppression_lists**; auto-prune role accounts unless confirmed.
- **Preference Center**: per-channel & per-category (Announcements, New Classes, Promotions), **frequency** (daily/weekly/monthly), locale.
- **Double opt-in** option for forms and list imports; **proof of consent** stored.
- **Quiet hours** by region; **legal footers** auto-inserted with mailing address and links.
- **GDPR/nLPD**: data export, deletion, lawful basis; transactional emails always allowed; **WhatsApp** requires explicit opt-in.

---

## 13) Analytics & Attribution
- **Funnel analytics**: step views, conversion %, revenue per visitor, A/B lifts, average order value, order bump/upsell take-rate.
- **Campaign analytics**: delivered/open/click/complaint/unsubscribe, **bookings & revenue**, heatmap of click blocks.
- **Journey analytics**: per-node metrics, goal conversion, time-to-goal; incremental lift via holdout.
- **Attribution models**: last-click (default), first-touch, position-based; compare models; **reconcile** with Finance.
- **Dashboards**: studio overview, campaign ROI, funnel performance, segment growth, list health (deliverability scores).

**APIs/RPCs**
- `report_campaign(campaign_id)`; `report_funnel(funnel_id)`; `report_journey(journey_id)` → JSON for dashboards.

---

## 14) Integrations
- **ESP**: Brevo/Sendgrid adapters (plug-in provider architecture).
- **SMS**: Twilio/MessageBird; sender ID registration where needed.
- **WhatsApp Business**: templates, 24h window logic.
- **Ads**: GA4 + Meta via consent-aware wrapper; **audience sync** to Meta/Google (hashed).
- **Calendars**: ICS attach on confirmation; “Add to calendar” buttons with UTM preserve.

---

## 15) Settings
- Brand tokens (colors, logo, typography); default template set per locale.
- Default **UTM** schema + link shortener domain.
- Quiet hours, frequency caps, channel priorities.
- Default legal blocks per locale (footer snippets, address).
- Default **goal** for newsletters (e.g., “any booking within 7d”) and attribution window.

---

## 16) AI Copilot (optional but recommended)
- **Subject line** & **preheader** generator with tone/length controls (FR/DE/IT/EN).
- **Copy blocks**: transforms (shorter, punchier, translate, formal/relaxed).
- **Image**: on-brand variants, crop suggestions, accessibility alt-text.
- **Audience suggestions**: “people who… looked at Yin last week and are within 5km”.
- **Send-time recommendations** per locale; **auto-A/B** suggestion with predicted winner.
- **Journey recipes**: prebuilt flows (new student onboarding, win-back 30/60/90d, churn-risk rescue).

---

## 17) APIs & Webhooks (selected)
- **Write**: `create_campaign`, `update_campaign`, `schedule_campaign`, `create_journey`, `publish_journey`, `create_funnel`, `publish_page`, `create_segment`, `snapshot_segment`.
- **Execute**: `send_test_email`, `shorten_link`, `assign_coupon_to_audience`, `enroll_in_journey`.
- **Events**: `lead.created`, `form.submitted`, `campaign.sent`, `message.bounced`, `journey.goal_reached`, `funnel.checkout_completed`, `referral.converted`.

---

## 18) Jobs & Scaling
- Message dispatcher with back-pressure (provider rate limits), retries, dead-letter queue.
- Segment refresh scheduler; journey step executor; A/B winner selector.
- Page publish → static pre-render + CDN; image optimization pipeline.

---

## 19) RLS & Permissions
- **Org-scoped** access; instructors limited to their lists (if enabled) and cannot export PII without permission.
- **Impersonation** logged; all changes **audited** (who/what/before→after).

---

## 20) QA & Acceptance Criteria
- **Consent honored**: no marketing sent to opted-out channels; transactional bypass works.
- **No double-send**: journeys dedupe within 24h; frequency caps enforced.
- **A/B math**: winner selection reproducible; sample sizes respected.
- **Attribution**: campaign revenue equals Finance within ±1% for matched windows.
- **Deliverability**: bounces/complaints land in suppression within 60s; sender domain checks pass.
- **Funnels**: 1-click upsell works with tokenized payment; order bump appears and charges correctly.
- **Localization**: all messages & pages render in chosen locale; fallbacks defined.

---

## 21) Edge Cases & Policies
- Importing lists: require **proof of consent** or trigger double opt-in; throttle sends.
- Shared devices/emails across households: dedupe + household logic; still respect per-person consent.
- WhatsApp 24h window: journeys gate sends appropriately; fallback to SMS/email if allowed.
- Abandoned checkout on subscription with failed dunning: route to recovery journey, add coupon if policy permits.

---

## 22) Example End-to-End Flows

### (A) New Student Onboarding
1. Lead submits opt-in form on funnel landing → double opt-in email.  
2. On confirm: Journey sends welcome + “first class free” coupon; segment tags “New-Onboard”.  
3. If **booking** occurs → journey exits (goal); else reminders at +3d/+7d; win-back at +30d.

### (B) Workshop Launch Funnel
1. Ads → Sales page → Checkout with order bump (guide PDF).  
2. Post-purchase: 1-click upsell (recorded course).  
3. Journey sends pre-event info; post-event survey email; upsell pass/membership.

### (C) Membership Dunning & Recovery
1. Payment failed → Journey retries (email + SMS), adds 3-day grace.  
2. Day 4: partial entitlement removal; send “pause or downgrade” options.  
3. Success path resumes; failure path cancels + win-back later.

---

## 23) Implementation Tasks (engineer-ready)

**Backend/DB**
- Create tables listed in §4 with indexes; enable RLS; add `org_id` default context.
- Implement RPCs: `evaluate_segment`, `snapshot_segment`, `schedule_campaign`, `ab_select_winner`, `enroll_in_journey`, `emit_event`, `assign_coupon_to_audience`, `shorten_link`.
- Provider adapters (email/SMS/WhatsApp) with webhook endpoints for delivery/bounce/complaint.
- Attribution joiners: `attribution_events` ↔ `orders` ↔ `campaigns/journeys/funnels`.
- Static publishing service for pages; CDN headers; image optimizer.

**Frontend (Web Admin)**
- Segment builder UI; Campaign composer (blocks library, AB, STO); Journey canvas with nodes.  
- Funnel builder (steps, themes, forms, SEO); Template library; Asset manager.  
- Deliverability dashboard (domain status, health scores); Preference center editor.  
- Analytics dashboards (campaign, funnel, journey, segment growth, ROI).

**Mobile**
- Deep link handling for campaigns/funnels; push journey actions; in-app inbox (optional).

**Settings**
- Brand tokens; default legal blocks; quiet hours; channel priorities; UTM defaults.

---

## 24) Inter-Module Contracts (key integrations)
- **Customers/Leads**: unified subject model; conversion upgrades lead→customer preserve attribution.
- **Registrations**: booking/cancel events feed journeys & attribution.
- **Products**: coupons, gift cards, pricing (show on pages), order bumps, upsells.
- **Finance**: net/gross revenue write-backs for ROI.
- **Campaigns (Retreats/Programs/Guides)**: prebuilt page/journey templates; tiered reminders; post-event upsells.
- **Online Studio**: “continue watching” & completion events as journey triggers; course sales funnels.

---

This version transforms Marketing into a **full-stack growth platform**: build funnels, grow the list, automate lifecycle journeys, send gorgeous newsletters, and tie every click back to **actual bookings and revenue**—with Swiss/EU compliance from day one.
