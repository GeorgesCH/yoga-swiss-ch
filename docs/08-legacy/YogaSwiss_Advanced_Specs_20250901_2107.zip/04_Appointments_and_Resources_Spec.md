# Appointments & Resources — Full Requirements and Spec (1:1 Scheduling)

Implementation-ready specification for true appointments (1:1 / small group up to n) with resource constraints, provider availability, intake forms, payments, rescheduling/cancellation, and calendar sync. Swiss/EU-ready (CHF, VAT incl/excl, TWINT/SEPA), multilingual (FR/DE/IT/EN).

---

## 1) Scope & Objectives
- Offer **services** (e.g., Private Yoga, Physio) that can be **in-person** or **virtual**.
- Generate **bookable slots** from provider availability + resource constraints + buffers.
- Allow **instant-book** or **request-to-book** with approval.
- Support **deposits**, **payment plans**, **packages/passes**, and **memberships**.
- Ensure conflict-free scheduling across **provider**, **room**, and **equipment**.
- Provide intake forms, automated reminders, ICS + two-way Google/Outlook sync.

---

## 2) Core Concepts
- **Service**: duration, buffers (pre/post), price model, location modes.
- **Provider**: staff/instructor who performs the service; has availability and time-off.
- **Resource**: room/equipment/slot capacity required by the service.
- **Slot**: candidate appointment time produced by availability × rules.
- **Appointment**: confirmed booking (buyer + attendee), linked to order/payment.
- **Intake Form**: per-service custom questions stored as snapshot on booking.

---

## 3) Data Model (high level)
- `services` (org_id, name_i18n, description_i18n, duration_min, buffer_before_min, buffer_after_min, max_party_size default 1, location_mode enum in_person/online/hybrid, price_model enum fixed/sliding/deposit_plan, base_price, tax_class, visibility public/unlisted/private, require_approval bool, cancellation_cutoff_h, reschedule_cutoff_h, forms_template_id, tags[])
- `service_resources` (service_id, resource_group_id, qty_required)  // e.g., Room:1 + Reformer:1
- `resources` (org_id, type enum room/equipment, name, location_id, seatmap_jsonb nullable, online_link default null, is_active)
- `resource_groups` (org_id, name, type, selection_rule enum any/all)  // resolve alternatives
- `providers` (staff_id FK; calendar_color, bio_short_i18n, rating_avg, is_bookable)
- `provider_services` (provider_id, service_id, price_override nullable, duration_override nullable, lead_time_min, cutoff_min, online_link_template)
- `provider_availability` (provider_id, rrule/weekly pattern JSON, tz, effective_from..to)
- `provider_exceptions` (provider_id, date or daterange, kind enum time_off/override, payload jsonb)
- `appointment_slots` (id, org_id, service_id, provider_id, start_at, end_at, location_id, resources_alloc_jsonb, capacity, status open/held/hidden, generated_at)
- `appointments` (id, org_id, slot_id, service_id, provider_id, customer_id, attendee_id, party_size, status pending_payment/confirmed/requested/canceled_by_client/canceled_by_studio/no_show, price_applied, entitlement enum price/pass/membership/comp, deposit_amount, balance_due_at, policy_snapshot jsonb, notes, created_at)
- `appointment_forms` (appointment_id, answers jsonb, files[])
- `appointment_audit` (appointment_id, actor_id, action, before_jsonb, after_jsonb, at)
- Indexes: (org_id, provider_id, start_at), (org_id, resource -> GIN) for conflicts.

RLS: org-scoped; customer sees own appointments; provider sees theirs.

---

## 4) Slot Generation & Conflict Engine
- Rolling window generation (e.g., next 60 days) via cron/edge function:
  - Take provider weekly availability + exceptions.
  - Apply service duration + buffers.
  - Check **resource availability** (room/equipment calendars).
  - Respect **lead time** (min hours before booking) & **cutoff**.
  - Yield slots; mark `hidden` if capacity zero.
- On booking: atomic allocation with `FOR UPDATE SKIP LOCKED` on slot and resource rows.
- Conflicts: provider/resource/timezone DST safe; reject overlaps.

---

## 5) Booking Flows
### 5.1 Client (Web/Mobile)
1. Choose service → pick provider (optional) → pick time slot.
2. Intake form (if any), add-ons, guest/party-size if allowed.
3. Payment: card/Apple/Google Pay, TWINT, account credit, pass/membership, deposit/plan.
4. Confirmation: ICS + reminders (email/push/SMS).

### 5.2 Request-to-Book
- Slot shows “Request”; admin/provider approves/denies.
- On approval, payment intent sent; hold window applies.

### 5.3 POS/Front Desk
- Quick create customer → pick slot → apply comp/collect payment → done.

---

## 6) Changes & Policies
- **Reschedule** within cutoff: move to another compatible slot; carry payments; price delta charged/refunded.
- **Cancel**: before cutoff → refund/credit per policy; after cutoff → apply late fee if configured.
- **No-show**: mark and optionally charge fee; membership exemptions possible.
- **Provider change**: suggest alternative providers; move appointment and notify.
- **Location/virtual change**: update map/Zoom link; ICS update.

---

## 7) Intake Forms
- Form builder per service (text, choice, date, file, conditional sections).
- Stored as **snapshot** on appointment; versioned; exportable.
- Privacy: instructor visibility toggles; auto-purge after retention period.

---

## 8) Calendar & Sync
- ICS attachments for confirmations & updates.
- Two-way sync (optional): connect Google/Outlook per provider; block out external events; push confirmed appointments to external calendar.
- Timezone handling per provider and per location.

---

## 9) APIs & RPCs
- `generate_slots(service_id, provider_id?, range)`
- `book_appointment(customer_id, slot_id, payload_json)` (idempotent key)
- `request_appointment(...)` / `approve_appointment(appointment_id)`
- `reschedule_appointment(appointment_id, slot_id)`
- `cancel_appointment(appointment_id, reason, actor)`
- `apply_intake(appointment_id, answers_json)`
- `conflicts(service_id, provider_id, start_at, end_at)`
- Webhooks: appointment.created/updated/canceled/rescheduled.

---

## 10) UI (Admin/Provider/Client)
- **Catalog** of services with price/duration/locations.
- **Provider calendar** (day/week) with drag-to-create blocks; time-off; conflict warnings.
- **Resource calendar** (rooms/equipment).
- **Slot list** with filters; bulk hide/show.
- **Appointment detail**: timeline, policy snapshot, forms, payments.
- Client UI shows provider bio, location map/online link, transparent price/tax.

---

## 11) Jobs & Reliability
- Nightly slot regeneration; on-change triggers for availability changes.
- Hold expirations to release un-paid bookings.
- DST test suite; concurrency tests on hot hours.

---

## 12) Acceptance Criteria
- No double-booking of provider or resources.
- Reschedules preserve payments and audit trail.
- Intake forms persist with correct visibility and retention.
- Two-way sync blocks conflicts within 60 seconds.
