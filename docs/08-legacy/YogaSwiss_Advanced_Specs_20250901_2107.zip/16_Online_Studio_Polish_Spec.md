# Online Studio Polish — Full Requirements and Spec (VOD + Livestream Enhancements)

Deepen the online experience: chapters/captions editor, premieres, progress challenges, DRM/signed URLs, continue watching, ratings & moderation, and mobile polish.

---

## 1) Objectives
- Bring online to parity with top fitness platforms while staying simple for studios.
- Improve discovery, engagement, and retention via structured content and progress.

---

## 2) Feature Set
- **Chapters editor** with thumbnails and titles; jump points.
- **Captions**: auto-generate + manual editor; multi-language tracks.
- **Premieres**: schedule a video drop with live chat; then auto-file to library.
- **Challenges/Courses**: sequences with prerequisites, streaks, and progress bars.
- **Continue Watching** synced across devices; resume at last timestamp.
- **DRM-lite**: signed URLs, token expiry, watermark overlay (optional) for anti-piracy.
- **Offline (mobile)**: encrypted downloads for members; license expiry.
- **Ratings/Comments**: verified viewers only; moderation queue, report abuse.
- **Recommendations**: next-up based on tags/history.

---

## 3) Data Model Additions
- `video_chapters` (video_id, t_sec, title, thumb_url)
- `caption_tracks` (video_id, lang, vtt_url, status)
- `premieres` (video_id, start_at, chat_room_id, status live/ended)
- `courses` (id, name_i18n, desc_i18n, publish_at, visibility)
- `course_items` (course_id, video_id, order_index, release_at, prerequisite_item_id nullable)
- `progress` (customer_id, video_id/course_id, pct, last_ts_sec, updated_at)
- `downloads` (device_id, video_id, license_expires_at, status)
- `video_ratings` (video_id, customer_id, stars, created_at)
- `video_comments` (video_id, customer_id, text, status pending/approved/rejected)
- `play_tokens` (video_id, customer_id, signed_url, expires_at, ip_hint, device_hint)

---

## 4) Player & Delivery
- HLS with ABR; signed URL per session; CORS + referrer checks.
- Picture-in-picture, AirPlay/Chromecast; variable speed; keyboard shortcuts.
- Accessibility: captions required; contrast & focus visible.

---

## 5) Workflows
- Upload → transcode → QC → publish → premiere (optional) → library.
- Auto-create recording from livestream and attach to class/events.
- Challenge builder: pick videos, release cadence (daily/weekly), streak rules.

---

## 6) UI
- Library with filters (duration, level, tag, language), search with typo-tolerance.
- Video page: chapters, related videos, ratings/comments, “Add to course/challenge”.
- Course/challenge page: progress tracker, day unlocks, badges.
- Mobile: downloads manager, continue watching row.

---

## 7) Acceptance Criteria
- Playback starts <2s on broadband; resumes position within 250ms accuracy.
- Captions editable and downloadable; chapters jump precisely.
- Downloads expire on schedule; tokens prevent hotlinking.
