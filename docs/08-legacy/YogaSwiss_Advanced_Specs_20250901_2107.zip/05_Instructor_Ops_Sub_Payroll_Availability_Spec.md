# Instructor Ops — Sub Requests, Payroll & Availability — Full Requirements and Spec

Operational features to keep schedules staffed and payroll accurate: substitution workflow, staff availability/time-off, and earnings rules with approvals and exports.

---

## 1) Scope & Objectives
- Smooth **substitution** flow when a teacher cannot teach.
- Clear **availability & time-off** tools to prevent conflicts.
- Granular **payroll** rules (per class/head/percent + bonuses/penalties), period close & export.

---

## 2) Data Model
- `sub_requests` (org_id, occurrence_id, owner_instructor_id, reason, status open/claimed/approved/denied/canceled, posted_at, expires_at)
- `sub_applications` (request_id, applicant_instructor_id, note, created_at, status applied/selected/rejected)
- `staff_availability` (instructor_id, rrule weekly pattern, tz, effective range)
- `staff_time_off` (instructor_id, daterange, reason, approved_by, status)
- `payroll_rules` (org_id, scope enum org/location/instructor/class_tag, model enum per_class/per_head/percent, value, min_pay, max_pay, bonuses_json, penalties_json)
- `earnings` (occurrence_id, instructor_id, computed_gross, adjustments, payable_on, paid_at)  // integrates with Finance
- `payroll_periods` (org_id, start_date, end_date, status open/approved/paid, exported_at)
- `payroll_adjustments` (instructor_id, period_id, amount, reason, author_id)

RLS: managers/owners edit; instructors read their own; auditors read-only.

---

## 3) Substitution Workflow
1. Instructor clicks **Request Sub** on occurrence (gives reason; optional preferred subs).
2. System notifies eligible instructors (match tags, certifications, availability, conflict-free).
3. Instructors **Apply**; studio **Selects** a sub (or auto-assign by rule).
4. Roster updates teacher; attendees auto-notified; earnings attribution updates.
5. If owner cancels the request, revert to original teacher.

Edge: last-minute sub → SMS + push escalation; require manager approval if policy says so.

---

## 4) Availability & Time-Off
- Weekly templates per instructor; color-coded availability blocks.
- Time-off requests with approval workflow; blocks new assignments.
- Conflict engine checks: overlapping classes, appointments, external calendar (if connected).
- Capacity and certification filters (e.g., Heated 26&2 requires certification tag).

---

## 5) Payroll Rules & Period Close
- Rule priority: (1) instructor-specific → (2) class tag/location → (3) org default.
- Models:
  - **Per class** fixed amount.
  - **Per head** × attendees (exclude comps if configured).
  - **Percent** of revenue (choose gross/net; include/exclude fees/discounts).
- **Bonuses**: high occupancy (>80%), multi-class same day, peak hour, 5★ rating streak.
- **Penalties**: late sub (<24h), no-show admin penalty.
- **Minimum/maximum** guardrails.
- Period close:
  - Compute earnings → review exceptions → apply adjustments → approve → export CSV/PDF → mark paid.
  - Lock period prevents retro changes (requires reopen with audit).

---

## 6) APIs & Jobs
- `request_sub(occurrence_id, reason)`; `apply_sub(request_id)`; `select_sub(request_id, applicant_id)`.
- `set_availability(instructor_id, pattern_json)`; `request_time_off(...)`.
- `compute_payroll(period)`; `close_payroll(period)`.
- Notifications: push/email/SMS hooks for sub offers, approvals, and payroll statements.

---

## 7) UI
- **Sub Center**: open requests, applicants, filters (certs, location), quick assign.
- **Instructor Calendar**: availability blocks, time-off, conflicts.
- **Payroll**: rule editor (with preview), period review, adjustments, exports; instructor earnings view.
- **Teacher Profile**: certifications/tags, payout method hints.

---

## 8) Acceptance Criteria
- Sub selection updates roster and notifications instantly.
- Payroll computes identically to Finance reports; adjustments tracked with audit.
- Availability conflicts prevented; time-off respected across schedulers.
