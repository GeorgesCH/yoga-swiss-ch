# Dynamic Pricing & Yield — Full Requirements and Spec

Price optimization features to maximize revenue and occupancy with transparent controls and auditability.

---

## 1) Objectives
- Automate **early-bird**, **last-minute**, and **capacity-based** pricing.
- Support **member vs public** pricing, **corporate rates**, and **A/B price tests**.
- Ensure fairness (min/max bounds), audit trail, and simple overrides for staff.

---

## 2) Pricing Inputs & Signals
- Time to start, current occupancy %, weekday/season, instructor rating, historical demand, promo calendars.
- Optional external signals: weather, local events (v2).

---

## 3) Data Model
- `pricing_rules` (org_id, scope enum org/location/class_template/occurrence, strategy enum early_bird/last_minute/capacity_ladder/ab_test/corporate, active_from..to, timezone, status)
- `price_ladders` (rule_id, steps jsonb)  // e.g., [ {lt_occ:40, price:18}, {lt_occ:70, price:22}, {else:26} ]
- `price_overrides` (occurrence_id or product_id, price, reason, author_id, expires_at)
- `ab_tests` (rule_id, variants [A:price, B:price], split %, winning_metric enum revenue/occupancy, min_sample)
- `corporate_rate_cards` (company_id, class_tag, price or discount%)
- `evaluations` (occurrence_id, evaluated_price, signals_jsonb, rule_ids[], decided_at, actor auto/manual)

---

## 4) Strategies
- **Early-bird**: lower price until X days/hours before start.
- **Last-minute**: discount if occupancy low at T-2h, with floor price.
- **Capacity ladder**: price rises as seats sell (e.g., every 20%). Optional price drop if cancellations reduce occupancy.
- **A/B test**: split audiences; pick winner by metric and auto-rollout.
- **Corporate**: fixed corporate price or % off when booking with company eligibility.

---

## 5) Evaluation & Caching
- Evaluate on page view/add-to-cart, and re-check at payment.
- Cache evaluated price for **short TTL** (e.g., 5 minutes) per user to reduce flicker.
- Always respect **min/max** and show **strike-through** when discounted.

---

## 6) UI & Controls
- Rule builder with preview (simulate occupancy/time to see price).
- Occurrence dashboard shows current **Effective Price**, ladder step, and audit trail.
- Manual override modal (with expiry) and reason.
- Student UI: “You saved CHF X (early bird)” label; transparent taxes.

---

## 7) APIs & Jobs
- `evaluate_price(occurrence_id, customer_id?)` returns price + explanation.
- `apply_override(occurrence_id, price, reason)`.
- Cron to finalize A/B tests after min sample and auto-activate winner.

---

## 8) Acceptance Criteria
- No price at checkout differs from page by > TTL unless rule changed; then banner explains change.
- Audit trail shows who/what/why for every price change.
- Revenue and occupancy lift visible in analytics (trend vs control).
