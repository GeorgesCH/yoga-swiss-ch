# Loyalty, Referrals & Reviews — Full Requirements and Spec

Delight customers and drive growth with points, tiers, rewards; friend referrals with fraud prevention; reviews/NPS with moderation.

---

## 1) Objectives
- Increase retention and referral-driven acquisition.
- Keep trust with transparent rules and moderation controls.

---

## 2) Data Model
- `points_ledger` (customer_id, delta, reason enum booking/checkin/referral/review/birthday/manual, balance_after, expiry_at nullable, actor_id, created_at)
- `tiers` (org_id, name, threshold_points, benefits_jsonb, color)
- `rewards_catalog` (id, type wallet_credit/free_class/discount/gift_card, cost_points, details_jsonb)
- `redemptions` (customer_id, reward_id, status pending/fulfilled/failed, payload jsonb)
- `referrals` (referrer_id, code, share_url, created_at, fraud_flags jsonb, reward_rule jsonb)
- `referral_conversions` (referral_id, referee_customer_id, order_id, qualified bool, reward_issued_at)
- `reviews` (target_type class/instructor/business, target_id, customer_id, rating 1..5, text, status pending/approved/rejected, flags_count, moderation_notes)
- `nps_surveys` (customer_id, score 0..10, comment, sent_at, answered_at)
- `achievements` (customer_id, badge_id, earned_at); `badges` (id, name, rule_jsonb).

---

## 3) Earning & Burning
- Earn: book/check-in, streaks, birthday, referrals (when referee books), reviews (approved).
- Burn: wallet credit, free class credit, % discounts, gift cards.
- Expiry: optional rolling expiry (e.g., 12 months); reminders before expiry.

---

## 4) Referrals
- Unique link + QR; deep links to app/web.
- Qualification rules: minimum order value, new customer only, cooldown.
- Fraud guard: device fingerprint, velocity checks, self-referral block, chargeback linkage.

---

## 5) Reviews & NPS
- Post-class prompt; limit to verified attendees.
- Moderation queue; profanity filter; right to be forgotten.
- Stars aggregate per class/instructor; snippets on public pages.
- NPS cadence (e.g., every 6 months); follow-ups for detractors.

---

## 6) UI
- **Customer**: points balance, activity, rewards store, referral page, badges.
- **Admin**: ledger, tier editor, reward catalog, referral performance, review moderation, NPS dashboards.

---

## 7) APIs & Jobs
- `earn_points(customer_id, reason, amount)`; `redeem_reward(customer_id, reward_id)`
- `create_referral(referrer_id)`; `qualify_referral(order_id)`
- Cron: expiry reminders; referral audits; review sampling; NPS sends.

---

## 8) Acceptance Criteria
- Points math consistent with bookings/refunds (reverse on refund).
- Referral rewards only after qualified purchase; fraud caught by rules.
- Reviews visible only after approval; moderation actions audited.
