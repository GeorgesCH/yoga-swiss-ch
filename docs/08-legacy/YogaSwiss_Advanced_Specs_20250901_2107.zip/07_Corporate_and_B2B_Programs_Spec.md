# Corporate & B2B Programs — Full Requirements and Spec

Serve employers and groups with account-level wallets, invoicing, and eligibility; deliver clean reporting and SSO.

---

## 1) Scope & Goals
- **Companies** with admins, employees, locations, and cost centers.
- **Eligibility** via email domain, SSO groups, or uploaded roster.
- **Company Wallets** (prepaid/postpaid) and **Monthly Invoices** with PO numbers.
- **Rate Cards** per company; caps (seats/month), blackout times, and reporting.

---

## 2) Data Model
- `companies` (org_id, name, domains[], billing_contact, billing_cycle, payment_terms, vat_id, address_jsonb, sso_provider enum none/saml/oidc, status active/suspended)
- `company_users` (company_id, customer_id, role admin/employee, cost_center, status)
- `company_wallets` (company_id, balance, credit_limit, currency, settlement monthly/quarterly, negative_allowed)
- `company_entitlements` (company_id, rules jsonb: eligible class_tags/locations/times, caps per period)
- `company_rate_cards` (company_id, class_tag or template, price or discount, tax_class)
- `company_invoices` (company_id, period, total, status, pdf_url, po_number, due_date)
- `company_statements` (company_id, period, details jsonb)
- `company_reports` materialized views for usage/cost per cost_center.

RLS by org & company admin roles.

---

## 3) Flows
- **Onboard company**: create company, set domains & SSO, rate card, entitlements, wallet/terms.
- **Join as employee**: sign up with @company.com → auto-link; or HR invite.
- **Booking**: if eligible, price uses company rate; payment: company wallet or invoice (postpaid).
- **Monthly close**: generate statement → invoice → send to billing contact; handle PO number; export CSV.
- **Caps**: stop or warn when monthly seat cap reached; allow overage with surcharge if configured.

---

## 4) SSO & Directory
- SAML/OIDC SSO for employees; optional SCIM provisioning.
- Map SSO group → entitlement rules (e.g., “HQ Only” plan).

---

## 5) UI
- **Company Admin** portal: roster, invites, cost centers, rate cards, caps, invoices, reports.
- **Studio Admin**: company list, AR aging, usage heatmaps, contract terms, adjustments.
- **Employee**: badge on pricing (“Covered by your company”), policy notes.

---

## 6) Acceptance Criteria
- Eligible employees see correct price and payment flow.
- Monthly invoices reconcile with bookings; PO included; aging tracked.
- Caps and overages enforced with clear messaging.
