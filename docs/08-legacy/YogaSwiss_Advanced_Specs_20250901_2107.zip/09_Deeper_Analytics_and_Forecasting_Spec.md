# Deeper Analytics & Forecasting — Full Requirements and Spec

From descriptive KPIs to predictive forecasts and cohort analysis. Privacy-first, exportable, and real-time enough for ops.

---

## 1) Objectives
- Understand revenue, occupancy, retention, and campaign ROI.
- Forecast demand and surface churn risk & staffing recommendations.

---

## 2) Data Architecture
- **Source**: Postgres OLTP with event streams.
- **Transform**: SQL models + materialized views; optional dbt project.
- **Serve**: Analytics schema for dashboards; CSV/Parquet exports; webhooks.

---

## 3) Core Marts / Views
- `mv_revenue_daily` (by product/location/channel/tax)
- `mv_occupancy_daily` (capacity, booked, show rate)
- `mv_retention_cohorts` (by signup month, product)
- `mv_ltv` (gross/net revenue per customer; CAC if provided)
- `mv_campaign_roi` (attribution joins)
- `mv_teacher_scorecards` (utilization, CSAT, reviews, earnings)
- `mv_pricing_effect` (price vs occupancy & revenue)
- `mv_churn_signals` (last visit, frequency drop, NPS, support tickets)
- `mv_forecast_inputs` (seasonality, weekday, weather stub, holidays)

---

## 4) Forecasting & Scoring
- Short-term **occupancy forecast** per class template and weekday (simple ETS/ARIMA or gradient features). 
- **Revenue forecast** by week.
- **Churn score** per customer (supervised or heuristic v1).
- **Staffing suggestion**: add/remove class when forecasted occupancy exceeds/falls below thresholds.

---

## 5) Dashboards
- **Studio Overview**: today/week revenue, occupancy, waitlist, refunds.
- **Product**: pass/membership sales, breakage, churn.
- **Pricing**: ladder performance, A/B winners.
- **Marketing**: campaign ROI, funnel, referrer sources.
- **Instructor**: utilization, earnings, ratings.
- **Corporate**: usage by company/cost center.

---

## 6) Exports & Integrations
- Scheduled CSV to S3/Drive; webhook on refresh; Looker/Metabase connectors.
- Privacy: PII redaction toggles; org-scoped API tokens.

---

## 7) Acceptance Criteria
- All totals reconcile with Finance reports.
- Forecast backtests published with MAPE; alerts explainability (top features).
- Dashboards load <2s on 90th percentile for last 90 days.
